     <span class="inline-flex justify-center items-center ml-1">
        {!!$icon!!}
      </span>
    
