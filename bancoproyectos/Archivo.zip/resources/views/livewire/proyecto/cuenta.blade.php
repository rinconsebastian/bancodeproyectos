    <span class="hidden md:block px-2 py-0.5 ml-auto text-xs font-medium tracking-wide {{$color}} rounded-full">{{$total}}</span>

