<span>{{$total}}</span>
