<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DependenciaController extends Controller
{
    //
}
