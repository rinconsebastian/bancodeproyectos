<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    
 
    
    <div class="  p-4 gap-4 flex flex-col flex-col-1">
    
        <?php if(session('info')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>
        <div class="card">
          <div class="card-header">Asignar rol</div>
            <div class="card-body">
                <p class="h5">Nombre:</p>
                <p><?php echo e($user->name); ?></p>
            
                
                <h2 class="h5">Listado de roles</h2>
                <?php echo Form::model($user, ['route'=> ['admin.users.update',$user],'method'=>'put']); ?>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label>
                        <?php echo Form::checkbox('roles[]', $role->id, null, ['class'=>'mr-1']); ?>

                        <?php echo e($role->name); ?>

                    </label>
                </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo Form::submit("Asignar rol", ['class'=>'btn btn-primary mt-2']); ?>

            <?php echo Form::close(); ?>

            </div>

        </div>
     




       
  
        
      </div>





   
 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>