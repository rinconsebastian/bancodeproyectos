<div>
   
    <?php if($revision != null): ?>
           <div class="rounded bg-gray-100 dark:bg-gray-800 p-3">



            <div class="flex justify-between py-1 text-black dark:text-white">
                <h3 class="text-sm font-semibold">Revisión <?php echo e($revision->created_at); ?></h3>
                
            </div>
            <div class="text-sm text-black dark:text-gray-50 mt-2">
                <h3 class="text-sm font-semibold">Observaciones</h3>
                <div
                    class="grid grid-cols-1  bg-white dark:bg-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 p-2 rounded mt-1 border-b border-gray-100 dark:border-gray-900 ">


                    <?php if($editrevision == true): ?>
                        <textarea wire:model.lazy="detalle" name="detalle" id="detalle"> </textarea>
                    <?php else: ?>
                        <p><?php echo e($revision->detalle); ?></p>
                    <?php endif; ?>

                </div>
                <h3 class="text-sm font-semibold">Documentos</h3>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proyecto.documentos-revisionx',['idRevision' => $revision->id,'edit'=>$editrevision])->html();
} elseif ($_instance->childHasBeenRendered('NFdkwOO')) {
    $componentId = $_instance->getRenderedChildComponentId('NFdkwOO');
    $componentTag = $_instance->getRenderedChildComponentTagName('NFdkwOO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NFdkwOO');
} else {
    $response = \Livewire\Livewire::mount('proyecto.documentos-revisionx',['idRevision' => $revision->id,'edit'=>$editrevision]);
    $html = $response->html();
    $_instance->logRenderedChild('NFdkwOO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>


        </div>

    
          
       
           
    <?php endif; ?>

</div>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/proyecto/revisionx.blade.php ENDPATH**/ ?>