<div>
    <h1>Hola mundo</h1>
</div>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/show-proyectos.blade.php ENDPATH**/ ?>