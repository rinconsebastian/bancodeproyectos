
<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
  
    
    
    <div class="grid grid-cols-1 lg:grid-cols-1 p-4 gap-4">
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proyecto.resumen',['idproyecto' => $proyecto])->html();
} elseif ($_instance->childHasBeenRendered('YhZsruD')) {
    $componentId = $_instance->getRenderedChildComponentId('YhZsruD');
    $componentTag = $_instance->getRenderedChildComponentTagName('YhZsruD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YhZsruD');
} else {
    $response = \Livewire\Livewire::mount('proyecto.resumen',['idproyecto' => $proyecto]);
    $html = $response->html();
    $_instance->logRenderedChild('YhZsruD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-1 p-4 gap-4">
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proyecto.historias',['idproyecto' => $proyecto])->html();
} elseif ($_instance->childHasBeenRendered('rGWsu3V')) {
    $componentId = $_instance->getRenderedChildComponentId('rGWsu3V');
    $componentTag = $_instance->getRenderedChildComponentTagName('rGWsu3V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rGWsu3V');
} else {
    $response = \Livewire\Livewire::mount('proyecto.historias',['idproyecto' => $proyecto]);
    $html = $response->html();
    $_instance->logRenderedChild('rGWsu3V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
      </div>

          
 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/proyectos/show.blade.php ENDPATH**/ ?>