    <span class="hidden md:block px-2 py-0.5 ml-auto text-xs font-medium tracking-wide <?php echo e($color); ?> rounded-full"><?php echo e($total); ?></span>

<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/proyecto/cuenta.blade.php ENDPATH**/ ?>