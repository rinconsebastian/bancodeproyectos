<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.resumen',['idusuario' => Auth::user()->id])->html();
} elseif ($_instance->childHasBeenRendered('r6IbhYM')) {
    $componentId = $_instance->getRenderedChildComponentId('r6IbhYM');
    $componentTag = $_instance->getRenderedChildComponentTagName('r6IbhYM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('r6IbhYM');
} else {
    $response = \Livewire\Livewire::mount('dashboard.resumen',['idusuario' => Auth::user()->id]);
    $html = $response->html();
    $_instance->logRenderedChild('r6IbhYM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 p-2 gap-4 h-tabla3">
    <!-- Borradores -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.marcotabla','data' => []]); ?>
<?php $component->withName('marcotabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('titulo'); ?> Borradores  <?php $__env->endSlot(); ?>
         <?php $__env->slot('boton'); ?> Ver todos  <?php $__env->endSlot(); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Borrador','usuario' => Auth::user()->id, ])->html();
} elseif ($_instance->childHasBeenRendered('EN2vv2K')) {
    $componentId = $_instance->getRenderedChildComponentId('EN2vv2K');
    $componentTag = $_instance->getRenderedChildComponentTagName('EN2vv2K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EN2vv2K');
} else {
    $response = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Borrador','usuario' => Auth::user()->id, ]);
    $html = $response->html();
    $_instance->logRenderedChild('EN2vv2K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- ./Borradores -->


        <!-- Devuletos -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.marcotabla','data' => []]); ?>
<?php $component->withName('marcotabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('titulo'); ?> Devueltos  <?php $__env->endSlot(); ?>
             <?php $__env->slot('boton'); ?> Ver todos  <?php $__env->endSlot(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Ajustes','usuario' => Auth::user()->id])->html();
} elseif ($_instance->childHasBeenRendered('muMDdFB')) {
    $componentId = $_instance->getRenderedChildComponentId('muMDdFB');
    $componentTag = $_instance->getRenderedChildComponentTagName('muMDdFB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('muMDdFB');
} else {
    $response = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Ajustes','usuario' => Auth::user()->id]);
    $html = $response->html();
    $_instance->logRenderedChild('muMDdFB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- ./Devuletos -->
  
        
      </div>





   
 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/proyectos/index.blade.php ENDPATH**/ ?>