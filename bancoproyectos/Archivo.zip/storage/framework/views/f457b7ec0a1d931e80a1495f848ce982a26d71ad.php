<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.resumen',['idusuario' => Auth::user()->id])->html();
} elseif ($_instance->childHasBeenRendered('ZqrVpqa')) {
    $componentId = $_instance->getRenderedChildComponentId('ZqrVpqa');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZqrVpqa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZqrVpqa');
} else {
    $response = \Livewire\Livewire::mount('dashboard.resumen',['idusuario' => Auth::user()->id]);
    $html = $response->html();
    $_instance->logRenderedChild('ZqrVpqa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 p-4 gap-4 h-5/6">
    <!-- Borradores -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.marcotabla','data' => []]); ?>
<?php $component->withName('marcotabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('titulo'); ?> Borradores  <?php $__env->endSlot(); ?>
         <?php $__env->slot('boton'); ?> Ver todos  <?php $__env->endSlot(); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Borrador','usuario' => Auth::user()->id, ])->html();
} elseif ($_instance->childHasBeenRendered('cRJSqNk')) {
    $componentId = $_instance->getRenderedChildComponentId('cRJSqNk');
    $componentTag = $_instance->getRenderedChildComponentTagName('cRJSqNk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cRJSqNk');
} else {
    $response = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Borrador','usuario' => Auth::user()->id, ]);
    $html = $response->html();
    $_instance->logRenderedChild('cRJSqNk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- ./Borradores -->


        <!-- Devuletos -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.marcotabla','data' => []]); ?>
<?php $component->withName('marcotabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('titulo'); ?> Devueltos  <?php $__env->endSlot(); ?>
             <?php $__env->slot('boton'); ?> Ver todos  <?php $__env->endSlot(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Ajustes','usuario' => Auth::user()->id])->html();
} elseif ($_instance->childHasBeenRendered('FfDBTD8')) {
    $componentId = $_instance->getRenderedChildComponentId('FfDBTD8');
    $componentTag = $_instance->getRenderedChildComponentTagName('FfDBTD8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FfDBTD8');
} else {
    $response = \Livewire\Livewire::mount('tables.show-proyectos',['estado' => 'Ajustes','usuario' => Auth::user()->id]);
    $html = $response->html();
    $_instance->logRenderedChild('FfDBTD8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <!-- ./Devuletos -->
  
        
      </div>





    <div class="py-12">
         <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                
                
                
               
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/proyectos/index.blade.php ENDPATH**/ ?>