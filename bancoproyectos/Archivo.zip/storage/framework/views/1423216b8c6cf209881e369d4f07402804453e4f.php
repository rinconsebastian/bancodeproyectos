<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="grid grid-cols-1 lg:grid-cols-1 p-4 gap-4">

        <div wire:id="tBdYTDOfBiGAAnPErBia">
            <div class="p-6 mr-2 bg-gray-100 dark:bg-gray-800 sm:rounded-lg">

                <div class="-mx-3 md:flex mb-6">
                    <div class=" px-3 mb-6 md:mb-0">
                        <h1 class="block uppercase tracking-wide text-2xl text-grey-darker font-bold mb-2">
                            Registrar nuevo proyecto
                        </h1>

                    </div>

                </div>
               <form action="<?php echo e(route('proyectos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="-mx-3 md:flex mb-6">
                    <div class="md:w-full px-3 mb-6 md:mb-0">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="nombre">
                            Nombre del proyecto
                        </label>
                        <input
                            class="appearance-none block w-full  bg-grey-lighter text-grey-darker border border-red rounded py-3 px-4 mb-3"
                            id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" placeholder="Nombre del proyecto">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                    </div>

                </div>
                <div class="-mx-3 md:flex mb-6">
                    <div class="md:w-1/2 px-3">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="fuente">
                            Fuente de Financiación
                        </label>
                        <select
                            class="appearance-none block w-full  value="<?php echo e(old('fuente')); ?>"  bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3"
                            name="fuente" id="fuente">
                            <option hidden selected value="">Selecciona una fuente de financiación</option>
                            <option  <?php echo e(old('fuente') == "Cooperación" ? "selected" : ""); ?> value="Cooperación">Cooperación</option>
                            <option <?php echo e(old('fuente') == "Regalias" ? "selected" : ""); ?> value="Regalias">Regalias</option>
                            <option <?php echo e(old('fuente') == "Propios" ? "selected" : ""); ?> value="Propios">Propios</option>
                        </select>
                        <?php $__errorArgs = ['fuente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                    </div>
                    <div class="md:w-1/2 px-3">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="valor">
                            Valor
                        </label>
                        <input
                            class="currency appearance-none block w-full bg-grey-lighter text-grey-darker text-right border border-grey-lighter rounded py-3 px-4"
                            type="number" placeholder="Valor del proyecto" min="1000" step="1" data-number-to-fixed="2"
                            data-number-stepfactor="100" id="valor" name="valor"  value="<?php echo e(old('valor')); ?>"  />
                            <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2" for="fase">
                            Fase
                        </label>
                        <select
                            class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3"
                            name="fase" id="fase"  value="<?php echo e(old('fase')); ?>" >
                            <option hidden selected value="">Selecciona una Fase</option>
                            <option  <?php echo e(old('fase') == "1" ? "selected" : ""); ?> value="1">I</option>
                            <option  <?php echo e(old('fase') == "2" ? "selected" : ""); ?> value="2">II</option>
                            <option  <?php echo e(old('fase') == "3" ? "selected" : ""); ?> value="3">III</option>
                            <option  <?php echo e(old('fase') == "4" ? "selected" : ""); ?> value="4">IV</option>
                            <option  <?php echo e(old('fase') == "5" ? "selected" : ""); ?> value="5">V</option>
                        </select>
                        <?php $__errorArgs = ['fase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="md:w-1/2 px-3">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="sector">
                            SECTOR
                        </label>
                        <div class="relative">
                            <select
                                class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3"
                                name="sector" id="sector" placehoder="seleccione"   >
                                <option hidden selected value="">Seleccione un sector</option>
                                <option  <?php echo e(old('sector') == "Público" ? "selected" : ""); ?> value="Público">Público</option>
                                <option <?php echo e(old('sector') == "Privado" ? "selected" : ""); ?> value="Privado">Privado</option>
                                <option  <?php echo e(old('sector') == "Alianza publico privada<" ? "selected" : ""); ?> value="Alianza publico privada">Alianza publico privada</option>
                                <option  <?php echo e(old('sector') == "Regalías" ? "selected" : ""); ?> value="Regalías">Regalías</option>

                            </select>
                            <?php $__errorArgs = ['sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="md:w-1/2 px-3">
                        <label class="block uppercase tracking-wide text-grey-darker text-xs font-bold mb-2"
                            for="tiempo"   >
                            Tiempo de ejecucion
                        </label>
                        <input
                            class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4"
                            id="tiempo" name="tiempo" type="number" placeholder="Tiempo en meses" value="<?php echo e(old('tiempo')); ?>">
                            <?php $__errorArgs = ['tiempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert alert-danger text-xs  italic text-red-600"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>
                <div class="-mx-3 md:flex mb-6">
                  <div class="md:w-full px-3 mb-6 md:mb-0">
                    
                    <button type="submit" class="inline-flex w-full justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                      Crear proyecto
                  </button>
                  
                </div>
              </form>

            </div>

        </div>




        <?php $__env->startSection("scriptsslot"); ?>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
            <script src="../js/webshim/polyfiller.js"></script>
            <script>
                webshims.setOptions('forms-ext', {
                    replaceUI: 'auto',
                    types: 'number',
                    number: {
                        "classes": "hide-inputbtns"
                    }
                });
                webshims.polyfill('forms forms-ext');
            </script>
        <?php $__env->stopSection(); ?>




 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/proyectos/create.blade.php ENDPATH**/ ?>