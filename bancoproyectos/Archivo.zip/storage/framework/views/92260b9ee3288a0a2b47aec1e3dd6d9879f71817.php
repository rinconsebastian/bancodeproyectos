<span><?php echo e($total); ?></span>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/proyecto/cuentaresumen.blade.php ENDPATH**/ ?>