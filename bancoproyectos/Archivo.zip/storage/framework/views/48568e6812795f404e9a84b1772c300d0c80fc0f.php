<?php if (isset($component)) { $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppbLayout::class, []); ?>
<?php $component->withName('appb-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    
 
    
    <div class="h-full  p-3 gap-4 flex flex-col flex-col-1">

        <?php if(session('info')): ?>
        <div class="alert alert-success">
            <?php echo e(session('info')); ?>

        </div>
            
        <?php endif; ?>
    <!-- Borradores -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.marcotabla','data' => []]); ?>
<?php $component->withName('marcotabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('titulo'); ?> Lista de roles  <?php $__env->endSlot(); ?>
         <?php $__env->slot('botonAccion'); ?> href="<?php echo e(route('admin.roles.create')); ?>" <?php $__env->endSlot(); ?>
         <?php $__env->slot('boton'); ?> Nuevo rol <?php $__env->endSlot(); ?>
        

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.roles-index')->html();
} elseif ($_instance->childHasBeenRendered('DMiTvyx')) {
    $componentId = $_instance->getRenderedChildComponentId('DMiTvyx');
    $componentTag = $_instance->getRenderedChildComponentTagName('DMiTvyx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DMiTvyx');
} else {
    $response = \Livewire\Livewire::mount('admin.roles-index');
    $html = $response->html();
    $_instance->logRenderedChild('DMiTvyx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- ./Borradores -->


       
  
        
      </div>





   
 <?php if (isset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e)): ?>
<?php $component = $__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e; ?>
<?php unset($__componentOriginal2db9969d0a937210421fe861aa5d54a504bad01e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>