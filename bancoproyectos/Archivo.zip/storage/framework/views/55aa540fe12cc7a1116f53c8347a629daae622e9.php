<div>
    
<?php
    $n = 0;
?>

<ul class="grid 2xl:grid-cols-3 lg:grid-cols-2 grid-cols-1 gap-0">
    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $extension = current(array_reverse(explode('.', $file->last()->url)));
    $n++;
    ?>
    <li class="text-xs">
        
        <?php if(($extension == 'pdf') | ($extension == 'jpeg') | ($extension == 'jpg') | ($extension == 'png')): ?>
                        <a title="<?php echo e($n); ?>. <?php echo e($file->last()->detalle); ?>" href="/public/storage/<?php echo e($file->last()->url); ?>" target="_blank" class=" text-xs cursor-pointer  relative flex flex-row items-center h-8 transition duration-500 transform ease-in-out hover:bg-gray-200">
                            <?php if (isset($component)) { $__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Iconofile::class, ['type' => ''.e($file->last()->tipo).'','size' => '24']); ?>
<?php $component->withName('iconofile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d)): ?>
<?php $component = $__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d; ?>
<?php unset($__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <span class="ml-2 text-sm tracking-normal truncate"><?php echo e($n); ?>. <?php echo e($file->last()->detalle); ?>  </span>      
                        </a>
                    <?php else: ?>
                        <a  title="<?php echo e($n); ?>. <?php echo e($file->last()->detalle); ?>" wire:click="export('<?php echo e($file->last()->id); ?>')"  class="text-xs cursor-pointer  relative flex flex-row items-center h-8 transition duration-500 ease-in-out transform hover:bg-gray-200">
                            <?php if (isset($component)) { $__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Iconofile::class, ['type' => ''.e($file->last()->tipo).'','size' => '24']); ?>
<?php $component->withName('iconofile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d)): ?>
<?php $component = $__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d; ?>
<?php unset($__componentOriginal66fe3ac6f85a82ac8e196590c60ee223ddf6639d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                         <span  class="ml-2 text-sm tracking-normal truncate"><?php echo e($n); ?>. <?php echo e($file->last()->detalle); ?></span>       
                        </a>
                    <?php endif; ?>
        
        
        
        </li>
   

 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
    
</div>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/proyecto/documentosaprobados.blade.php ENDPATH**/ ?>