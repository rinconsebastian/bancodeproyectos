<div class="overflow-x-auto overflow-y-auto h-full">
    <!-- This example requires Tailwind CSS v2.0+ -->
    
    <div class="px-6 py-4">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','wire:model' => 'search','class' => 'w-full','placeholder' => 'Escriba el nombre de un proyecto']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','wire:model' => 'search','class' => 'w-full','placeholder' => 'Escriba el nombre de un proyecto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>

    
        <?php if($proyectos->count() > 0): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col"
                            class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            N

                            
                        </th>
                        <th scope="col"
                            class="cursor-pointer  px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('id')">
                            Id

                            
                            <?php if($sort == 'id'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('name')">
                            Nombre
                           
                            <?php if($sort == 'name'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>

                        </th>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('user_id')">
                            Usuario
                            
                            <?php if($sort == 'user_id'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('fuente')">
                            Fuente
                            
                            <?php if($sort == 'fuente'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('valor')">
                            Valor
                            
                            <?php if($sort == 'valor'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('sector')">
                            Sector
                            
                            <?php if($sort == 'sector'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <?php if($displayestado == true): ?>
                        <th scope="col"
                            class="cursor-pointer px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            wire:click="order('estado')">
                            Estado
                            
                            <?php if($sort == 'estado'): ?>
                                <?php if($direction == 'asc'): ?>
                                    <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                <?php endif; ?>
                            <?php else: ?>
                                <i class="fas fa-sort float-right mt-1"></i>
                            <?php endif; ?>
                        </th>
                        <?php endif; ?>
                        <th scope="col" class="relative px-6 py-3">

                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                        $n = 1;
                    ?>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr   class="hover:bg-gray-200 cursor-pointer" wire:click="open('<?php echo e($proyecto->id); ?>')">
                            <td class="px-2 py-4 text-gray-500">
                                <?php echo e($n); ?>

                            </td>
                            <td class="px-2 py-4 text-gray-500">
                                <?php echo e($proyecto->id); ?>

                            </td>
                            <td class="px-2 py-4 ">
                                <?php echo e($proyecto->name); ?>

                            </td>
                            <td class="px-2 py-4">
                                <div class="text-sm text-gray-900"><?php echo e($proyecto->user->dependencia->name); ?></div>
                                <div class="text-sm text-gray-500"><?php echo e($proyecto->user->name); ?></div>
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($proyecto->fuente); ?>

                            </td>

                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e("$" . number_format($proyecto->valor, 2, ',', '.')); ?>


                            </td>
                            <td class="px-2 py-4 text-sm text-gray-500">
                                <?php echo e($proyecto->sector); ?>

                            </td>
                            <?php if($displayestado == true): ?>
                            <td class="px-2 py-4 whitespace-nowrap">
                                <span
                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    <?php echo e($proyecto->estado); ?>

                                </span>
                            </td>
                            
                            <?php endif; ?>
                            
                            <td class="px-2 py-4  text-right text-sm font-medium">

                            </td>
                        </tr>
                        <?php
                            $n++;
                           
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- More people... -->
                </tbody>
            </table>
        <?php else: ?>
            <div px 6 py-4>No existe ningun proyecto coincidente</div>
        <?php endif; ?>

</div>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/tables/show-proyectos.blade.php ENDPATH**/ ?>