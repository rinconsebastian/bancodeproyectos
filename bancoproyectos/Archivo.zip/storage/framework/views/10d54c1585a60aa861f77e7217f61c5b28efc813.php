     <span class="inline-flex justify-center items-center ml-1">
        <?php echo $icon; ?>

      </span>
    
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/components/iconofile.blade.php ENDPATH**/ ?>