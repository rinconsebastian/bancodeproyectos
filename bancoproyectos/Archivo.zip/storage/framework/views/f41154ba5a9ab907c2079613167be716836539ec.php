<div>
    <?php
        
        $num = $total;
        $open = "false";
    ?>
    <div class="w-full  mx-auto shadow-md">

        <?php $__currentLoopData = $historias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $open = "false";
                if ($num == $total) {
                    $open = "true";
                }
            ?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proyecto.historian',['idhistoria' => $historia->id, 'num'=>$num, 'open' => $open])->html();
} elseif ($_instance->childHasBeenRendered('mgSGoRx')) {
    $componentId = $_instance->getRenderedChildComponentId('mgSGoRx');
    $componentTag = $_instance->getRenderedChildComponentTagName('mgSGoRx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mgSGoRx');
} else {
    $response = \Livewire\Livewire::mount('proyecto.historian',['idhistoria' => $historia->id, 'num'=>$num, 'open' => $open]);
    $html = $response->html();
    $_instance->logRenderedChild('mgSGoRx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



            <?php
                $num--;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







    </div>



    
</div>
<?php /**PATH /Users/sebastian/Documents/GitHub/bancodeproyectos/bancoproyectos/resources/views/livewire/proyecto/historias.blade.php ENDPATH**/ ?>