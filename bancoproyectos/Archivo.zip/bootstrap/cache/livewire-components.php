<?php return array (
  'dashboard.resumen' => 'App\\Http\\Livewire\\Dashboard\\Resumen',
  'mainmenu' => 'App\\Http\\Livewire\\Mainmenu',
  'proyecto.cuenta' => 'App\\Http\\Livewire\\Proyecto\\Cuenta',
  'proyecto.cuentaresumen' => 'App\\Http\\Livewire\\Proyecto\\Cuentaresumen',
  'proyecto.documentos' => 'App\\Http\\Livewire\\Proyecto\\Documentos',
  'proyecto.documentos-revisionx' => 'App\\Http\\Livewire\\Proyecto\\DocumentosRevisionx',
  'proyecto.historian' => 'App\\Http\\Livewire\\Proyecto\\Historian',
  'proyecto.historias' => 'App\\Http\\Livewire\\Proyecto\\Historias',
  'proyecto.resumen' => 'App\\Http\\Livewire\\Proyecto\\Resumen',
  'proyecto.revisionx' => 'App\\Http\\Livewire\\Proyecto\\Revisionx',
  'sidemenu' => 'App\\Http\\Livewire\\Sidemenu',
  'tables.show-proyectos' => 'App\\Http\\Livewire\\Tables\\ShowProyectos',
);